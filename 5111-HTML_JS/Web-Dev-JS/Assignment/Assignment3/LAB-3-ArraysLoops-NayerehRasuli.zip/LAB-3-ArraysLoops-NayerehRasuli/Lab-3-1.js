//LAB 3 - ARRAYS & LOOPS - PART 1
//alert("Part 1");//COMMENT THIS OUT ONCE CONNECTED

//ARRAY OF FRUITS
var fruitBask = [ "Orange" , "Apple" , "Banana" , "Watermelon" , "Strawberry"];

//OUTPUT ONE FRUIT IN POPUP BOX
alert(fruitBask[2]);
